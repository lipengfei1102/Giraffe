package mvc.model;

import common.PersonType;
import container.Person;
import container.PersonExistsException;
import persons.Student;
import persons.Worker;

import java.io.*;

public class TextModel extends StandardModel {
    String filepath;
    public TextModel(String filepath, PersonType personType)
    {
        super();
        this.filepath = filepath;
        //���ı���ȡ
        BufferedReader reader = null;
        try {
            File file = new File(filepath);
            reader = new BufferedReader(new FileReader(file));//���׳�NOTFOUND���쳣
            String line;
            Person person = null;
            while((line = reader.readLine()) !=null)
            {
                if(personType == PersonType.Student)
                    person = Student.makeStudent(line);
                else if(personType == PersonType.Worker)
                    person = Worker.makeWorker(line);
                if(person == null)
                {
                    if(viewer !=null)
                        viewer.showCriticalMessage("�޷��ӣ���" + line + "������Person��һ������ʵ����");
                    continue;
                }

                container.insert(person);
            }
        }catch (FileNotFoundException e)
        {
            if(viewer !=null)
                viewer.showCriticalMessage("�ļ�����" + filepath + "��������");
        }
        catch (IOException e)
        {
            if(viewer !=null)
                viewer.showCriticalMessage("��ȡ�ļ�����" + filepath + "��������IO�쳣��" + e.getMessage());
        }
        catch (PersonExistsException e)
        {
            if(viewer !=null)
                viewer.showCriticalMessage("����ID��ͬ�Ķ����������������");
        }
        finally {
            if(reader !=null)
            {
                try{
                    reader.close();
                }catch(IOException E){}
            }
        }
    }

    @Override
    public void save() {
        //����Ϊ�ı�
        //���浽���л����ļ�
        BufferedWriter out = null;
        try {
            File fileInfo = new File(filepath);
            out = new BufferedWriter(new FileWriter(fileInfo));
            for(Object p : container)
            {
                out.write(p.toString());
                out.newLine();
            }

        } catch (Exception e) {
            if(viewer !=null)
                viewer.showCriticalMessage("�����ݱ����ڡ�" + filepath + "����ʧ�ܣ�" + e.getMessage());
        }
        finally {
            if(out !=null)
            {
                try{
                    out.close();
                }
                catch (IOException E){}
            }
        }
    }

    @Override
    public void process_delete() {
        super.process_delete();
        //ÿ�β���֮���������л�
        save();
    }

    @Override
    public void process_insert() {
        super.process_insert();
        save();
    }

    @Override
    public void process_modify() {
        super.process_modify();
        save();
    }
}