package mvc.controler;
import common.PersonType;
import mvc.model.Model;
import mvc.model.StandardModel;
import mvc.viewer.CommandViewer;
import java.util.Scanner;

public class CommandControler extends Controler {
    private static final void showStudentMenu() {
        String s = "1.����ѧ����Ϣ\n2.�г�ѧ����Ϣ\n3.��ѯѧ����Ϣ\n4.ɾ��ѧ����Ϣ\n5.�޸�ѧ����Ϣ\n6.������һ���˵�";
        System.out.println(s);
    }
    private static final void showWorkerMenu() {
        String s = "1.���ӹ�����Ա��Ϣ\n2.�г�������Ա��Ϣ\n3.��ѯ������Ա��Ϣ\n4.ɾ��������Ա��Ϣ\n5.�޸Ĺ�����Ա��Ϣ\n6.������һ���˵�";
        System.out.println(s);
    }
    private static final void showMenus() {
        System.out.println("ѧУ��Ϣ����ϵͳ\n1.ѧ������ϵͳ\n2.���˹���ϵͳ\n3.�˳�ϵͳ");
    }
    public CommandControler(){
        super();
    }
    private void stu(Scanner scanner) {
        Model stuModel = this.stringModelHashMap.getOrDefault(PersonType.Student, null);
        if (stuModel == null || stuModel.getViewer() == null || !(stuModel.getViewer() instanceof CommandViewer)) {
            System.err.println("û��ָ������ģ�ͺ���ȷ����������ͼ");
            return;
        }
        //��ʾ

        showStudentMenu();
        int code = scanner.nextInt();
        while (code != 6) {
            switch (code) {
                case 1:
                    stuModel.process_insert();
                    break;
                case 2:
                    stuModel.process_list();
                    break;
                case 3:
                    stuModel.process_query();
                    break;
                case 4:
                    stuModel.process_delete();
                    break;
                case 5:
                    stuModel.process_modify();
                    break;
                case 6:
                    return;
            }
            showStudentMenu();
            code = scanner.nextInt();

        }
    }
    private void worker(Scanner scanner) {
        Model workModel = this.stringModelHashMap.getOrDefault(PersonType.Worker, null);
        if (workModel == null || workModel.getViewer() == null || !(workModel.getViewer() instanceof CommandViewer)) {
            System.err.println("û��ָ������ģ�ͺ���ȷ����������ͼ");
            return;
        }
        //��ʾ
        showWorkerMenu();
        int code = scanner.nextInt();
        while (code != 6) {
            switch (code) {
                case 1:
                    workModel.process_insert();
                    break;
                case 2:
                    workModel.process_list();
                    break;
                case 3:
                    workModel.process_query();
                    break;
                case 4:
                    workModel.process_delete();
                    break;
                case 5:
                    workModel.process_modify();
                    break;
                case 6:
                    return;
            }
            showWorkerMenu();
            code = scanner.nextInt();
        }
    }
    private void doAction(Scanner scanner){
        showMenus();
        int code = scanner.nextInt();
        while (code != 3) {
            switch (code) {
                case 1:
                    stu(scanner);
                    break;
                case 2:
                    worker(scanner);
                    break;
            }
            showMenus();
            code = scanner.nextInt();
        }

        System.out.println("�ټ���");

    }

    @Override
    public void show() {
        doAction(new Scanner(System.in));
    }
}