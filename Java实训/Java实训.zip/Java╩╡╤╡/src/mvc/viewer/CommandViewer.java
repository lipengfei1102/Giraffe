package mvc.viewer;
import common.PersonType;
import container.IContainer;
import container.Person;
import persons.Student;
import persons.Worker;
import java.awt.event.ActionListener;
import java.util.*;

public class CommandViewer implements Viewer {

	private Person queried_person;
	private PersonType viewType;
	public CommandViewer(PersonType viewType){
		this.viewType = viewType;
	}

	@Override
	public void showInfoMessage(String msg) {
		System.out.println(msg);
	}

	@Override
	public void showCriticalMessage(String msg) {
		System.err.println(msg);
	}
	@Override
	public Person getNewPersonFromUserInput(boolean idEditable, Person oldPerson) {
		//�Ȳ���ѧ����
		assert(idEditable== false && oldPerson !=null);
		Scanner scanner= new Scanner(System.in);
		String id="", name;
		if(oldPerson != null)
		{
			System.out.println("ԭʼ����Ϣ��" + oldPerson);
			id = oldPerson.getId();
		}

		int age;
		System.out.println("������������");
		name = scanner.nextLine();
		if(idEditable == true)//���Բ��޸�ID
		{
			System.out.println("������ID��");
			id = scanner.next();//ID�����пո�
		}
		System.out.println("���������䣺");
		age = scanner.nextInt();
		if(viewType == PersonType.Student)
		{
			float grade;
			System.out.println("������ɼ���");
			grade = scanner.nextFloat();
			return new Student(id, name, age, grade);
		}
		else{
			//����
			String job;
			float salary;
			scanner.nextLine();//���age�Ķ���س�
			System.out.println("�����빤����");
			job = scanner.nextLine();
			System.out.println("�����빤�ʣ�");
			salary = scanner.nextFloat();
			return new Worker(id, name, age, job, salary);
		}
	}

	@Override
	public Person getSelectedPerson() {
		return queried_person;
	}

	@Override
	public String getUserInput(String title, String text) {
		//����һЩ�ı�
		System.out.println(title + ":");
		System.out.println(text);
		Scanner scanner= new Scanner(System.in);
		String id;
		id = scanner.nextLine();
		return id;
	}

	@Override
	public void changeTitleText(String title) {
		System.out.println(title);
	}

	@Override
	public void showAllPersons(IContainer c) {
		for(Person person : c)
		{
			System.out.println(person);
		}
	}

	@Override
	public void showPersonInfo(Person p) {
		System.out.println("ѧ����" + p);
	}

	@Override
	public void setSelectedPerson(Person person) {
		queried_person = person;
	}

	@Override
	public boolean askUserYesOrNo(String text) {
		System.out.println(text + "��Y,y/n��");
		Scanner scanner = new Scanner(System.in);
		String res = scanner.next();
		if(res.equals("Y") || res.equals("y"))
			return true;
		else
			return false;
	}
	@Override
	public boolean askToRefreshList() {
		return askUserYesOrNo("�Ƿ�����������ͼ��");
	}

	@Override
	public int askManyOptions(String title, String text, String[] optionsText) {
		if(optionsText == null || optionsText.length == 0)
			return -1;
		showInfoMessage(title + ":");
		showInfoMessage(text);
		for(int i=0;i<optionsText.length;++i)
			showInfoMessage("\t" + i + "." + optionsText[i]);
		Scanner scanner = new Scanner(System.in);
		int code = scanner.nextInt();
		if(code >= 0 && code < optionsText.length)
			return code;
		else
			return -1;//�Ƿ�������
	}

	@Override
	public int showQueryPersonsResultAndGetSelectResult(String title, String text, Collection res) {
		if(res ==null || res.size() <= 0){
			return -1;
		}
		System.out.println(title + ":");
		System.out.println(text + "���������ţ�:");
		//������ֽ��
		Object[] o = res.toArray();
		for(int i=0;i<o.length;++i){
			System.out.println("\t" + i + "." + o[i]);
		}
		Scanner scanner = new Scanner(System.in);
		int code = scanner.nextInt();
		if(code >= 0 && code < o.length)
			return code;
		else
			return -1;//�Ƿ�������
	}
	@Override
	public boolean needAddBuutonActionListener() {
		return false;
	}

	@Override
	public void addActionListenerToButtons(ActionListener actionListener) {

	}
}