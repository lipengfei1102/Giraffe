package database.dao;

public class SQLPrimaryKeyInTheSameException extends Exception{
    public SQLPrimaryKeyInTheSameException(String msg){
        super(msg);
    }
}
