package database.dao;

public class SQLPrimaryKeyNotFoundException extends Exception{
    public SQLPrimaryKeyNotFoundException(String msg) {
        super(msg);

    }
}

