import java.util.regex.Pattern;

public class Other {
    public static void main(String[] a){
        Pattern p = Pattern.compile("()");
    }
}