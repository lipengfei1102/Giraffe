package container;

public class PersonExistsException extends Exception {
	public PersonExistsException(String msg){
		super(msg);
	}
}