package container;
import java.util.*;
import java.io.*;
import java.util.function.BiFunction;

public class PersonsList implements IContainer, Serializable, Iterable<Person> {
	private ArrayList<Person> persons;//���Ͱ�ȫ�İ汾
	public PersonsList(){
		persons = new ArrayList<Person>();
	}
	public void insert(Person p) throws PersonExistsException {
		assert (p != null);
		ArrayList<Person> tar = query(p, (Person l ,Person r)->l.getId().equals(r.getId()));
		if (tar.size() == 0) {
			persons.add(p);//������
		} else {
			throw new PersonExistsException("����ʧ�ܣ��Ѿ����ڵ�Ŀ�꣺" + p.toString());
		}

	}
	public ArrayList<Person> query(Person p, BiFunction<Person, Person, Boolean> pred){
		assert(p != null);
		ArrayList<Person> results = new ArrayList<>();
		for(Person pp : persons)
		{
			if(pred.apply(p, pp))
				results.add(pp);
		}
		return results;
	}
	public void delete(Person p) throws PersonNotFoundException{
		assert(p != null);
		ArrayList<Person> target = query(p, (Person l ,Person r)->l.getId().equals(r.getId()));
		if(target.size() > 0)
		{
			//������� ����ֻ��һ��ID������ɾ��p����
			for(Person pp : target)
				persons.remove(pp);
		}
		else{
			throw new PersonNotFoundException("ɾ��ʧ�ܣ�û���ҵ�Ŀ�꣺" + p.toString());
		}
	}
	public int count(){
		return persons.size();
	}

	public void modify(Person p, Person newInfo)throws PersonNotFoundException{
		assert(p != null);
		assert(newInfo != null);
		ArrayList<Person> target = query(p, (Person l ,Person r)->l.getId().equals(r.getId()));
		if(target.size() > 0)//ԭ����
		{
			p.copyFrom(newInfo);
		}
		else{
			throw new PersonNotFoundException("�޸�ʧ�ܣ�û���ҵ�Ŀ�꣺" + p.toString());
		}
	}
	public Iterator iterator(){
		return persons.iterator();
	}
	
}