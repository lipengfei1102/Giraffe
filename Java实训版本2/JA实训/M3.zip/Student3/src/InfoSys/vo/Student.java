package InfoSys.vo;

import InfoSys.vo.Person;

public class Student extends Person{
	 float score;
	 public Student(String ID,String name,int age,float score){
		 super(ID,name,age);
		 this.score=score;
	 }
	 public Student(String id)  
	    {  	
		 	super(id);
	    } 
	 public void putAge(int age){
		 this.age=age;
	 }

	 public void putScore(float score){
		 this.score=score;
	 }
	 public float getScore(){
		 return score;
	 }
	 public  String toString(){ 
		 return "ѧ�ţ�"+this.getID()+"\t"+"������"+this.getName()+"\t���䣺"+this.getAge() +"\t�ɼ���"+score;
	 }//ת��Ϊ�ַ���
}
