package InfoSys.controller;

import java.util.List;
import java.util.Set;

import InfoSys.model.InfoSysModel;
import InfoSys.view.Gui_stu;
import InfoSys.view.InfoSysView;
import InfoSys.vo.Student;

public class InfoSysControllerImpl_stu implements InfoSysController_stu  
{  
    private InfoSysModel infoSysModel;  
    private InfoSysView infoSysView;  
    public InfoSysControllerImpl_stu(InfoSysModel model,InfoSysView view)  
    {  
        try{  
            infoSysModel=model;  
            infoSysView=view;  
            view.addUserGestureListener(this);  
        }catch(Exception e)  
        {  
            reportException(e);  
        }  
    }  
    //�����쳣��Ϣ  
    private void reportException(Object o)  
    {  
        try{  
            infoSysView.showDisplay(o);  
        }catch(Exception e)  
        {  
            System.out.println("StoreControllerImpl reportException "+e);  
        }  
    }  
 
	@Override
	public void handleAddGesture(Student stu) { 
		        try{  
		            infoSysModel.add(stu);
		            infoSysModel.fireModelChangeEvent(stu);
		        }catch(Exception e)  
		        {  
		            reportException(e);  
		        }  
		
	}
	public void handleShowGesture(Student stu) throws Exception {
		 try{  
	            infoSysModel.show(stu);  
	        }catch(Exception e)  
	        {  
	            reportException(e);  
	        }  
		
	}
	public void handleFindByIDGesture(String id) throws Exception {
		Student stu=null;  
		
        try{  
            stu=infoSysModel.findByID(id);//����InfoSysModel����ȥ���ݿ��ȡָ��ID����Ա����  
            infoSysView.showDisplay(stu);//ͨ��InfoSysView��ʾ����  
        }catch(Exception e)  
        {  
            reportException(e);  
            stu=new Student(id);  
            try{  
                infoSysView.showDisplay(stu);  
            }catch(Exception ex)  
            {  
                reportException(ex);  
            }  
        }  
	}
	
	public void handleFindByNameGesture(String name) throws Exception {
		Student stu=null;  
        try{  
            stu=infoSysModel.findByName(name);//����InfoSysModel����ȥ���ݿ��ȡָ��name����Ա����  
            infoSysView.showDisplay(stu);//ͨ��InfoSysView��ʾ����  
        }catch(Exception e)  
        {  
            reportException(e);  
            stu=new Student(name);  
            try{  
                infoSysView.showDisplay(stu);  
            }catch(Exception ex)  
            {  
                reportException(ex);  
            }  
        }  
		
	}
	
	public void handleDelGesture(Student stu) throws Exception {
		try{  
            infoSysModel.del(stu);  
        }catch(Exception e)  
        {  
            reportException(e);  
        }  
		
	}
	public void handleModGesture(Student stu) throws Exception {

        try{  
            infoSysModel.mod(stu);  
        }catch(Exception e)  
        {  
            reportException(e);  
        }  
		
	}
	@Override
	public Object handleReadGesture() throws Exception {
		 try{  
	            infoSysModel.read();  
	        }catch(Exception e)  
	        {  
	            reportException(e);  
	        }
		return null;  
	}
	@Override
	public void handleSaveGesture(List<Student> it) throws Exception {
		 try{  
	            infoSysModel.save(it);  
	        }catch(Exception e)  
	        {  
	            reportException(e);  
	        }  
		
	}
	@Override
	public void handleGetAllStudent() {
		   
	        try{  
	        	Set<Student> students=null;
	        	students=infoSysModel.getAllStudent();//ͨ��StoreModel������������Ա��Ϣ  
	        	infoSysView.showDisplay(students);//ͨ��StoreView��ʾ����
	             
	        }catch(Exception e)  
	        {  
	            reportException(e);  
	        }  
		
	}  
  
}  