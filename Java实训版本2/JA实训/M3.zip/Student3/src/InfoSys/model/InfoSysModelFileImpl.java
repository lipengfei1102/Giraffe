package InfoSys.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.Writer;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import InfoSys.vo.Student;
import InfoSys.view.Gui_stu;
import InfoSys.view.InfoSysView;;
public class InfoSysModelFileImpl implements InfoSysModel  {
	private ArrayList<InfoSysView> changeListeners=new ArrayList<InfoSysView>(10);  
	public static List<Student> stus=new ArrayList<Student>();
	//private transient Gui_stu gui;  
	public  void L1(List<Student> stu) {
		stus=stu;
	}
	public boolean check (String id){
		Iterator<Student> it= stus.iterator();
		while(it.hasNext()){
			Student stu=it.next();
			if(id.equals(stu.getID())){
				return true;
			}
		}return false;
	}
	
	 /**ע����ͼ���Ա㵱ģ���޸������ݿ��е���Ա��Ϣʱ���Իص���ͼ��ˢ�½���ķ���*/  
    public void addChangeListener(InfoSysView iv) throws RemoteException {  
          
        changeListeners.add(iv);  
    }  
		
		public Object read() throws Exception{
				stus.clear();//��ֹ�����ظ�
				File f = new File("students.txt");
				if(f.exists()) {
					
				InputStream in = new FileInputStream(f); 
		        Scanner s = new Scanner(in); 
				try {
					Scanner l = null;
					String line = null;
					while(s.hasNextLine())
					{
						line = s.nextLine();
						l = new Scanner(line);
						l.useDelimiter("----");
						String id = l.next();
						String name = l.next();
						stus.add(new Student(id,name,l.nextInt(),l.nextFloat()));
		
					}
				}catch(Exception e) {
					throw e;
				}finally {
					try {
						s.close();
					}catch(Exception e) {}
				}
				System.out.println("------��ȡѧ����Ϣ�ɹ�------");
			}
				else
					{System.out.println("�ļ���ȡ������������Ŀ��Ŀ¼�Ƿ�����Ϊstudents���ı�,��û�������ó����������ݲ�����");}
				return stus;
		}
		public void save(List<Student> it) throws Exception{
			Writer out = new FileWriter("students.txt");//,true ׷��д��
			Iterator<Student> iter = ((ArrayList<Student>)stus).iterator();
			while(iter.hasNext()) {
				Student stu = (Student)iter.next();
				out.write(stu.getID()+"----"+stu.getName()+"----"+stu.getAge()+"----"+stu.getScore()+"\r\n");
			}
			out.flush();
			out.close();
			System.out.println("------����ѧ����Ϣ�ɹ�------");
			
		}
		@Override
		public void add(Student stu) throws Exception {

	
			String id = Gui_stu.idTf.getText();
			String name = Gui_stu.nameTf.getText();
			int age = Integer.valueOf(Gui_stu.ageTf.getText());
			float score = Integer.valueOf(Gui_stu.scoreTf.getText());
			if(this.check(stu.getID()))
			{Gui_stu.updateLog("ID�Ѵ��ڣ�");}
			else
			{	read();
				stus.add(new Student(id,name,age,score));
				Gui_stu.updateLog("���ӳɹ���");
				save(stus);}
			
		}
		@Override
		public void show(Student stu) throws Exception {
			Gui_stu.updateLog("ˢ�³ɹ���");
			
		}
		@Override
		public Student findByID(String id) throws Exception {
			
			boolean Find = false;
	        id= Gui_stu.idTf.getText();
	        Iterator<Student> it= stus.iterator();
	        Student stud  = null;
			while(it.hasNext()){
				Student stu=(Student)it.next();
				if(stu.getID().equals(id)){
					Gui_stu.nameTf.setText(stu.getName());
					Gui_stu.ageTf.setText(String.valueOf(stu.getAge()));
					Gui_stu.scoreTf.setText(String.valueOf(stu.getScore()));
					Find = true;
					Gui_stu.updateLog("���ҵ�");
					Gui_stu.updateLog(stu.toString());
					stud =  stu;
				}
			} 
			
				if(!Find) {
					Gui_stu.updateLog("û����λͬѧ����Ϣ");;}
				return stud;
			
		}
		@Override
		public Student findByName(String name) throws Exception {
			boolean Find = false;
	        name= Gui_stu.nameTf.getText();
	        Iterator<Student> it= stus.iterator();
	        Student stud  = null;
			while(it.hasNext()){
				Student stu=(Student)it.next();
				if(stu.getName().matches("(.*)"+name+"(.*)")){
					Gui_stu.idTf.setText(stu.getName());
					Gui_stu.nameTf.setText(stu.getName());
					Gui_stu.ageTf.setText(String.valueOf(stu.getAge()));
					Gui_stu.scoreTf.setText(String.valueOf(stu.getScore()));
					Find = true;
					Gui_stu.updateLog("���ҵ�");
					Gui_stu.updateLog(stu.toString());
					stud =  stu;
				}
			} 
			
				if(!Find) {
					Gui_stu.updateLog("û����λͬѧ����Ϣ");;}
				return stud;
			
		}
		@Override
		public void del(Student stu) throws Exception {
			 String id = Gui_stu.idTf.getText();
	         
	         Iterator<Student> it= stus.iterator();
	     	while(it.hasNext()){
	     		    stu=(Student)it.next();
					if(stu.getID().equals(id)){
						it.remove();
						save(stus);
						Gui_stu.updateLog("ɾ���ɹ�");
						break;}
					else if(!it.hasNext())
						Gui_stu.updateLog("û���ҵ�");
	     		}		
			
		}
		@Override
		public void mod(Student stu) throws Exception {
			String id = Gui_stu.idTf.getText();
	         
	        Iterator<Student> it= stus.iterator();
	     	while(it.hasNext()){
	     		    stu=(Student)it.next();
					if(stu.getID().equals(id)){
						stu.putName(Gui_stu.nameTf.getText());
						stu.putAge(Integer.valueOf(Gui_stu.ageTf.getText()));
						stu.putScore(Integer.valueOf(Gui_stu.scoreTf.getText()));
						save(stus);
						Gui_stu.updateLog("�޸ĳɹ�");
						break;}
					else if(!it.hasNext())
						Gui_stu.updateLog("û���ҵ�");
	     		}		
			
		}
		public Set<Student> getAllStudent() throws Exception {   
			
	          Set<Student> stuSet=new HashSet<Student>();  
	          Student stu;  
			  File f = new File("students.txt");
			  if(f.exists()) {
				  Gui_stu.updateLog("�ļ�����");
				  InputStream in = new FileInputStream(f); 
			        Scanner s = new Scanner(in); 
					try {
						Scanner l = null;
						String line = null;
						while(s.hasNextLine())
						{
							line = s.nextLine();
							l = new Scanner(line);
							l.useDelimiter("----");
							String id = l.next();
							String name = l.next();
							stu = new Student(id,name,l.nextInt(),l.nextFloat());
							stuSet.add(stu);
						}
						
					}catch(Exception e) {
						throw e;
					}finally {
						try {
							s.close();
						}catch(Exception e) {}
					}
			  }
			  return stuSet;  
		}
		/**�����ݿ�����Ա��Ϣ�����仯ʱ��ͬ��ˢ��������ͼ*/  
	    public void fireModelChangeEvent(Student stu)  
	    {  
	    	InfoSysView v;  
	        for(int i=0;i<changeListeners.size();i++)  
	        {  
	            try{  
	                v=changeListeners.get(i);  
	                v.handleStudentChange(stu);  
	            }catch(Exception e)  
	            {  
	                System.out.println(e.toString());  
	            }  
	        }  
	    }  
}

